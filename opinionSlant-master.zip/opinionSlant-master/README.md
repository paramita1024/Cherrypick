# opinionSlant
